create view title_with_user(id, title, userid, username, email) as
SELECT c.id,
       c.title,
       c.user_id AS userid,
       u.username,
       u.email
FROM todolist.category c
         JOIN todolist.user_data u ON c.user_id = u.id;

alter table title_with_user
    owner to postgres;

