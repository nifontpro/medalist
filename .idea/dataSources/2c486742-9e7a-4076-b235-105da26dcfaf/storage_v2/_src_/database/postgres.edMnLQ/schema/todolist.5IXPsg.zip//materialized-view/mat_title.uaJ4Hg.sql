create materialized view mat_title as
SELECT c.id,
       c.title,
       c.user_id AS userid,
       u.username,
       u.email
FROM todolist.category c
         JOIN todolist.user_data u ON c.user_id = u.id;

alter materialized view mat_title owner to postgres;

